# JNTUH Java Lab Programs

Java practical programs for lab preparation.

## Programs
1. Traffic light using radio buttons; recursive directory listing
2. Three-thread random number program; name/phone lookup using HashMap
3. Producer-consumer using inter-thread communication; display CSV table using GridLayout
4. Doubly linked list and deletion
5. Integer division GUI with exception handling; mouse events using adapter classes
6. Abstract Shape class; simple calculator using GridLayout

## Compile and run
Open a terminal in this folder and run, for example:

```bash
javac ListDirectoryFiles.java
java ListDirectoryFiles
```

GUI programs require a desktop environment. `NamePhoneHashMap.java` expects `contacts.txt`
with name and phone separated by a tab. `DisplayCSVGrid.java` expects `Table.txt`
with comma-separated values. Sample files are included.
