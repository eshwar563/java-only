import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class MouseEventsAdapter extends JFrame {
    JLabel label = new JLabel("Perform a mouse action", SwingConstants.CENTER);
    public MouseEventsAdapter() {
        add(label);
        addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) { show("Mouse Clicked"); }
            public void mousePressed(MouseEvent e) { show("Mouse Pressed"); }
            public void mouseReleased(MouseEvent e) { show("Mouse Released"); }
            public void mouseEntered(MouseEvent e) { show("Mouse Entered"); }
            public void mouseExited(MouseEvent e) { show("Mouse Exited"); }
        });
        addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseMoved(MouseEvent e) { show("Mouse Moved"); }
            public void mouseDragged(MouseEvent e) { show("Mouse Dragged"); }
        });
        setSize(400, 250); setDefaultCloseOperation(EXIT_ON_CLOSE); setVisible(true);
    }
    void show(String s) { label.setText(s); }
    public static void main(String[] args) { SwingUtilities.invokeLater(MouseEventsAdapter::new); }
}
