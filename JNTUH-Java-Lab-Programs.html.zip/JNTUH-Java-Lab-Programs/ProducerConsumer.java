class Buffer {
    private int value;
    private boolean available = false;
    synchronized void produce(int v) throws InterruptedException {
        while (available) wait();
        value = v;
        available = true;
        System.out.println("Produced: " + value);
        notifyAll();
    }
    synchronized int consume() throws InterruptedException {
        while (!available) wait();
        available = false;
        System.out.println("Consumed: " + value);
        notifyAll();
        return value;
    }
}
public class ProducerConsumer {
    public static void main(String[] args) {
        Buffer b = new Buffer();
        Thread producer = new Thread(() -> {
            try { for (int i = 1; i <= 5; i++) b.produce(i); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        Thread consumer = new Thread(() -> {
            try { for (int i = 1; i <= 5; i++) b.consume(); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        producer.start(); consumer.start();
    }
}
