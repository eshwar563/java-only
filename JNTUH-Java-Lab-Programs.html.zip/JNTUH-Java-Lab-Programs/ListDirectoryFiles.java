import java.io.File;
import java.util.Scanner;
public class ListDirectoryFiles {
    static void list(File folder) {
        File[] items = folder.listFiles();
        if (items == null) return;
        for (File item : items) {
            System.out.println(item.getAbsolutePath());
            if (item.isDirectory()) list(item);
        }
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter directory path: ");
        list(new File(sc.nextLine()));
    }
}
