import javax.swing.*;
import java.awt.*;
public class IntegerDivisionGUI extends JFrame {
    JTextField num1 = new JTextField(8), num2 = new JTextField(8), result = new JTextField(8);
    public IntegerDivisionGUI() {
        setTitle("Integer Division");
        setLayout(new FlowLayout());
        result.setEditable(false);
        JButton divide = new JButton("Divide");
        add(new JLabel("Num1")); add(num1); add(new JLabel("Num2")); add(num2);
        add(divide); add(new JLabel("Result")); add(result);
        divide.addActionListener(e -> {
            try {
                int a = Integer.parseInt(num1.getText().trim());
                int b = Integer.parseInt(num2.getText().trim());
                result.setText(String.valueOf(a / b));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter valid integers");
            } catch (ArithmeticException ex) {
                JOptionPane.showMessageDialog(this, "Cannot divide by zero");
            }
        });
        setSize(350, 150); setDefaultCloseOperation(EXIT_ON_CLOSE); setVisible(true);
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(IntegerDivisionGUI::new); }
}
