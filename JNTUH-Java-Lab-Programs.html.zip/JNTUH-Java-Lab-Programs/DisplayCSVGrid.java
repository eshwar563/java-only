import javax.swing.*;
import java.awt.*;
import java.io.*;
public class DisplayCSVGrid extends JFrame {
    public DisplayCSVGrid() throws IOException {
        setTitle("Table from File");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        java.util.List<String[]> rows = new java.util.ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader("Table.txt"))) {
            String line;
            while ((line = br.readLine()) != null) rows.add(line.split(",", -1));
        }
        int cols = rows.isEmpty() ? 1 : rows.get(0).length;
        setLayout(new GridLayout(rows.size(), cols, 5, 5));
        for (String[] row : rows)
            for (int i = 0; i < cols; i++)
                add(new JLabel(i < row.length ? row[i].trim() : "", SwingConstants.CENTER));
        pack();
        setSize(500, Math.max(150, rows.size() * 35));
        setVisible(true);
    }
    public static void main(String[] args) throws IOException {
        SwingUtilities.invokeLater(() -> {
            try { new DisplayCSVGrid(); }
            catch (IOException e) { JOptionPane.showMessageDialog(null, e.getMessage()); }
        });
    }
}
