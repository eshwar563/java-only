import java.util.Scanner;
class Node {
    int data; Node prev, next;
    Node(int data) { this.data = data; }
}
public class DoublyLinkedListDelete {
    Node head;
    void add(int value) {
        Node n = new Node(value);
        if (head == null) head = n;
        else {
            Node t = head;
            while (t.next != null) t = t.next;
            t.next = n; n.prev = t;
        }
    }
    void delete(int value) {
        Node t = head;
        while (t != null && t.data != value) t = t.next;
        if (t == null) { System.out.println("Element not found"); return; }
        if (t.prev != null) t.prev.next = t.next; else head = t.next;
        if (t.next != null) t.next.prev = t.prev;
    }
    void display() {
        for (Node t = head; t != null; t = t.next) System.out.print(t.data + " ");
        System.out.println();
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        DoublyLinkedListDelete list = new DoublyLinkedListDelete();
        System.out.print("How many elements? ");
        int n = sc.nextInt();
        System.out.println("Enter elements:");
        for (int i = 0; i < n; i++) list.add(sc.nextInt());
        System.out.print("Enter element to delete: ");
        list.delete(sc.nextInt());
        System.out.print("List after deletion: ");
        list.display();
    }
}
