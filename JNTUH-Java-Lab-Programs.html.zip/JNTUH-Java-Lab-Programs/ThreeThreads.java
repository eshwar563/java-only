import java.util.Random;
public class ThreeThreads {
    static final Object lock = new Object();
    static int number;
    static boolean available = false;

    public static void main(String[] args) {
        Thread generator = new Thread(() -> {
            Random random = new Random();
            try {
                while (true) {
                    synchronized (lock) {
                        while (available) lock.wait();
                        number = random.nextInt(100);
                        System.out.println("Generated: " + number);
                        available = true;
                        lock.notifyAll();
                    }
                    Thread.sleep(1000);
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });

        Thread even = new Thread(() -> process(true));
        Thread odd = new Thread(() -> process(false));
        generator.start(); even.start(); odd.start();
    }

    static void process(boolean wantEven) {
        try {
            while (true) {
                synchronized (lock) {
                    while (!available || (number % 2 == 0) != wantEven) lock.wait();
                    if (wantEven) System.out.println("Square: " + (number * number));
                    else System.out.println("Cube: " + (number * number * number));
                    available = false;
                    lock.notifyAll();
                }
            }
        } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
