import javax.swing.*;
import java.awt.*;
public class TrafficLight extends JFrame {
    public TrafficLight() {
        setTitle("Traffic Light");
        setSize(300, 220);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new FlowLayout());
        JLabel message = new JLabel("");
        message.setFont(new Font("Arial", Font.BOLD, 24));
        ButtonGroup group = new ButtonGroup();
        JRadioButton red = new JRadioButton("Red");
        JRadioButton yellow = new JRadioButton("Yellow");
        JRadioButton green = new JRadioButton("Green");
        group.add(red); group.add(yellow); group.add(green);
        add(message); add(red); add(yellow); add(green);
        red.addActionListener(e -> { message.setText("Stop"); message.setForeground(Color.RED); });
        yellow.addActionListener(e -> { message.setText("Ready"); message.setForeground(Color.ORANGE); });
        green.addActionListener(e -> { message.setText("Go"); message.setForeground(Color.GREEN.darker()); });
        setVisible(true);
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(TrafficLight::new); }
}
