abstract class Shape {
    int a, b;
    Shape(int a, int b) { this.a = a; this.b = b; }
    abstract void printArea();
}
class Rectangle extends Shape {
    Rectangle(int l, int w) { super(l, w); }
    void printArea() { System.out.println("Rectangle area: " + (a * b)); }
}
class Triangle extends Shape {
    Triangle(int base, int height) { super(base, height); }
    void printArea() { System.out.println("Triangle area: " + (0.5 * a * b)); }
}
class Circle extends Shape {
    Circle(int radius) { super(radius, 0); }
    void printArea() { System.out.println("Circle area: " + (Math.PI * a * a)); }
}
public class AbstractShape {
    public static void main(String[] args) {
        new Rectangle(10, 5).printArea();
        new Triangle(10, 5).printArea();
        new Circle(7).printArea();
    }
}
