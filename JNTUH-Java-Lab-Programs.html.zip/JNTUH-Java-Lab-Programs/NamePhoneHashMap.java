import java.io.*;
import java.util.*;
public class NamePhoneHashMap {
    public static void main(String[] args) throws IOException {
        Map<String, String> phones = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader("contacts.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] p = line.split("\\t");
                if (p.length >= 2) phones.put(p[0].trim(), p[1].trim());
            }
        }
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name or phone: ");
        String key = sc.nextLine().trim();
        if (phones.containsKey(key)) System.out.println("Phone: " + phones.get(key));
        else {
            String name = null;
            for (Map.Entry<String, String> e : phones.entrySet())
                if (e.getValue().equals(key)) name = e.getKey();
            System.out.println(name == null ? "Record not found" : "Name: " + name);
        }
    }
}
