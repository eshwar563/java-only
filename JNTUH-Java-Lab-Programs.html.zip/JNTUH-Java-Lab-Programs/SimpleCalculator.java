import javax.swing.*;
import java.awt.*;
public class SimpleCalculator extends JFrame {
    JTextField display = new JTextField();
    double first; String operator = "";
    public SimpleCalculator() {
        setTitle("Simple Calculator");
        setLayout(new BorderLayout());
        display.setEditable(false); add(display, BorderLayout.NORTH);
        JPanel panel = new JPanel(new GridLayout(4, 4, 5, 5));
        String[] keys = {"7","8","9","+","4","5","6","-","1","2","3","*","0","C","=","%"}; 
        for (String key : keys) {
            JButton button = new JButton(key); panel.add(button);
            button.addActionListener(e -> press(key));
        }
        add(panel, BorderLayout.CENTER);
        setSize(300, 300); setDefaultCloseOperation(EXIT_ON_CLOSE); setVisible(true);
    }
    void press(String key) {
        try {
            if (key.matches("\\d")) display.setText(display.getText() + key);
            else if (key.equals("C")) { display.setText(""); operator = ""; }
            else if (key.equals("=")) {
                double second = Double.parseDouble(display.getText());
                double answer;
                if (operator.equals("+")) answer = first + second;
                else if (operator.equals("-")) answer = first - second;
                else if (operator.equals("*")) answer = first * second;
                else if (operator.equals("%")) answer = first % second;
                else answer = second;
                display.setText(String.valueOf(answer)); operator = "";
            } else {
                first = Double.parseDouble(display.getText());
                operator = key; display.setText("");
            }
        } catch (ArithmeticException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid calculation");
            display.setText(""); operator = "";
        }
    }
    public static void main(String[] args) { SwingUtilities.invokeLater(SimpleCalculator::new); }
}
